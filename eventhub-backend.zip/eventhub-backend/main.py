from fastapi import FastAPI, HTTPException
from fastapi.middleware.cors import CORSMiddleware
from fastapi.responses import HTMLResponse
from pydantic import BaseModel
from datetime import datetime
from pathlib import Path

# Main app instance
app = FastAPI()

# middleware configuration
app.add_middleware(
    CORSMiddleware,
    allow_origins=["*"],
    allow_credentials=True,
    allow_methods=["*"],
    allow_headers=["*"],
)

# local var to store events parameters
events = []
registrations = []
event_id_counter = 1
registeration_id = 1


# -----------------------------------------------------
# Front End 
# -----------------------------------------------------
@app.get("/", response_class=HTMLResponse)
def serve_frontend():
    """
    Front End HTML page served at:
        http://localhost:8000/
    
    Place the main.py file in the same directory as the Event Registration interface HTML file
    (e.g., index.html) and ensure that the HTML file is named correctly. 
    When you run the FastAPI application, it will serve the HTML page at the root URL, 
    allowing users to interact with the event registration interface.
    """
    
    current_folder = Path(__file__).parent
    
    possible_filenames = [
                          "index.html", 
                          "event_registration.html", 
                          "event_registration_interface.html"
    ]
    
    for filename in possible_filenames:
        html_file = current_folder / filename
        if html_file.exists():
                return html_file.read_text(encoding="utf-8")

    return """
!DOCTYPE html>
    <html>
      <head>
        <title>EventHub Frontend Not Found</title>
        <style>
          body {
            font-family: Arial, sans-serif;
            background: #0f1117;
            color: #e8eaf6;
            padding: 40px;
            line-height: 1.6;
          }
          code {
            background: #21253a;
            padding: 3px 6px;
            border-radius: 5px;
          }
        </style>
      </head>
      <body>
        <h1>EventHub frontend file not found</h1>
        <p>Put your HTML file in the same folder as <code>main.py</code>.</p>
        <p>Expected filename:</p>
        <p><code>index_clickable_calendar_mount_year_type.html</code></p>
        <p>Then restart the server:</p>
        <p><code>uvicorn main:app --reload</code></p>
      </body>
    </html>
    """
# -----------------------------------------------------
# Object Data retrival and update
# -----------------------------------------------------
class EventCreate(BaseModel):
    title: str
    description: str
    date: datetime
    max_capacity: int
    
class EventUpdate(BaseModel):
    title: str | None = None
    description: str | None = None
    date: datetime | None = None
    max_capacity: int | None = None

class RegistrationCreate(BaseModel):
    user_name: str
    user_email: str

class UnregisterRequest(BaseModel):
    user_email: str

# -----------------------------------------------------
# Event API methods
# -----------------------------------------------------
@app.get("/api/events")
def get_events():
    return events

@app.post("/api/events")
def create_event(event: EventCreate):
    global event_id_counter
    
    new_event = {
        "id": event_id_counter,
        "title": event.title,
        "date": event.date,
        "description": event.description,
        "max_capacity": event.max_capacity,
        "current_capacity": 0
    }
    
    events.append(new_event)
    event_id_counter += 1
    
    return new_event

@app.get("/api/events{event_id}")
def get_event(event_id: int):
    for event in events:
        if event["id"] == event_id:
            return event

    raise HTTPException(status_code=404, detail="Event not found") 


@app.patch("/api/events/{event_id}")
def update_event(event_id: int, event_update: EventCreate):
    for event in events:
        if event["id"] == event_id:
            if event_update.title is not None:
                event["title"] = event_update.title
            if event_update.date is not None:
                event["date"] = event_update.date
            if event_update.description is not None:
                event["description"] = event_update.description
            if event_update.max_capacity is not None:
                # Ensure max_capacity cannot be set below current_capacity
                if event_update.max_capacity < event["current_capacity"]:
                    raise HTTPException(status_code=400, detail="max_capacity cannot be less than current_capacity")
                event["max_capacity"] = event_update.max_capacity
            return event

    raise HTTPException(status_code=404, detail="Event not found")

@app.delete("/api/events/{event_id}")
def delete_event(event_id: int):
    global events, registrations
    event_exists = any(event["id"] == event_id for event in events)
    if not event_exists:
        raise HTTPException(status_code=404, detail="Event not found")
    
    events = [event for event in events if event["id"] != event_id]
    registrations = [reg for reg in registrations if reg["event_id"] != event_id]
    
    return [reg for reg in registrations if reg["event_id"] == event_id]


# -----------------------------------------------------
# Registration API methods
# -----------------------------------------------------
@app.get("/api/registrations/event/{event_id}/registrations")
def get_registrations(event_id: int):
    event_exists = any(event["id"] == event_id for event in events)
    
    if not event_exists:
        raise HTTPException(status_code=404, detail="Event not found")
    
    return [reg for reg in registrations if reg["event_id"] == event_id]


@app.post("/api/registrations/events/{event_id}/register")
def register_for_event(event_id: int, registration: RegistrationCreate):
    global registeration_id
    
    e = None 
    for event in events:
        if event["id"] == event_id:
            e = event
            break
            
    if event is None:
        raise HTTPException(status_code=404, detail="Event not found")
    
    if event["current_capacity"] >= event["max_capacity"]:
        raise HTTPException(status_code=400, detail="Event is at full capacity")

    new_registration = {
        "id": registeration_id,
        "event_id": event_id,
        "user_name": registration._user_name,
        "user_email": registration._user_email,
        "registration_date": datetime.now().isoformat()
    }
    
    registrations.append(new_registration)
    registeration_id += 1
    event["current_capacity"] += 1
    
    return new_registration


@app.delete("/api/registrations/event/{event_id}/unregister")
def unregister_from_event(event_id: int, unregister_request: UnregisterRequest):
    global registrations
    
    for reg in registrations:
        if reg["event_id"] == event_id and reg["user_email"].lower() == unregister_request._user_email.lower():
            registrations.remove(reg)
            
            for event in events:
                if event["id"] == event_id:
                    event["current_capacity"] = max(0, event["current_capacity"] - 1)
                    
            return {"detail": "Unregistered successfully"}
        
    raise HTTPException(status_code=404, detail="Registration not found")